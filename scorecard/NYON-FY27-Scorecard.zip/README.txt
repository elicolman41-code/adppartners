NYON FY27 — BEYOND PAYROLL SCORECARD
=====================================

HOW TO USE
1. Double-click "NYON-FY27-Beyond-Payroll-Scorecard.html".
   It opens in any browser (Chrome, Safari, Edge, Firefox) and
   works fully offline — no internet needed.

2. Fill in your name and team at the top.

3. Enter your FY27 GOALS directly in the "Goal (FY27)" column
   of each product card (Retirement, PEO, MAS).

4. Enter your actuals each month in the MONTHLY SCORECARD grid
   (bottom-left). Everything else updates automatically:
     - the YTD Actual columns in the cards
     - the % Revenue Goal Achieved gauges
     - the FY27 Beyond Payroll Revenue Summary (bottom-right)

   The monthly grid is the single source of truth — type once,
   the whole scorecard recalculates live.

5. Your data saves automatically in the browser. Close it and
   reopen anytime — your numbers are still there.

6. Use "Print / PDF" (top-right) for a clean landscape printout
   or to save a PDF snapshot. "Reset" clears everything.

Numbers are tracked in whole dollars / whole counts.

New York or Nowhere
