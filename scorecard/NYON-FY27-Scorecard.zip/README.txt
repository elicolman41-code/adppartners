NYON FY27 — BEYOND PAYROLL SCORECARD
=====================================

HOW TO USE
1. Double-click "NYON-FY27-Beyond-Payroll-Scorecard.html".
   Opens in any browser, works fully offline.

2. Enter your name and team at the top.

3. Set your FY27 GOALS in the "Goal (FY27)" column of each
   product card (Retirement, PEO, MAS).

4. Enter actuals in the MONTHLY SCORECARD grid (bottom-left).

   FAST NUMBER ENTRY (revenue):
     - Type 1.2  ->  $1,200
     - Type 5.1  ->  $5,100
     - Type 10.5 ->  $10,500
     - Whole numbers stay literal: 1200 -> $1,200
   A live preview shows exactly what you'll get as you type.

   QUICK MONTH FILL:
     - Click a month button to highlight that column.
     - Press Enter or Tab to jump down the column and fill a
       whole month fast. Shift+Tab moves back up.

   Everything recalculates live: YTD columns, the % gauges,
   and the FY27 Beyond Payroll Revenue Summary.

5. Your data saves automatically in the browser. Reopen anytime.

6. "Print / PDF" (top-right) for a clean landscape printout.
   "Reset" clears everything.

New York or Nowhere
