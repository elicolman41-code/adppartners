NYON FY27 — BEYOND PAYROLL SCORECARD
=====================================

HOW TO USE:
1. Double-click "NYON-FY27-Beyond-Payroll-Scorecard.html"
   It opens in any web browser (Chrome, Safari, Edge, Firefox).
   No internet connection required — it works fully offline.

2. SET GOALS tab — enter your FY27 annual targets for
   Retirement, PEO, and MAS.

3. MONTHLY ENTRY tab — pick a month and type in your actuals.
   The progress gauges update live.

4. YEAR TO DATE tab — see your full-year totals, revenue
   summary, and the 12-month grid.

Your numbers save automatically in the browser. Close it and
reopen anytime — everything is still there.

NOTE: Data is saved per-browser on the device you use it on.
To keep a backup, use your browser's print-to-PDF on the
Year to Date tab.

New York or Nowhere
